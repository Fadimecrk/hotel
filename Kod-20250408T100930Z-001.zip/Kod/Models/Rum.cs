﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelApp.Models;

public class Rum
{
    public int Id { get; set; }
    public string Rumsnummer { get; set; }
    public string Typ { get; set; }
    public decimal PrisPerNatt { get; set; }

    public ICollection<Bokning> Bokningar { get; set; }
}
