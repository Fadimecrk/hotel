﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelApp.Models;

public class Bokning
{
    public int Id { get; set; }

    public int KundId { get; set; }
    public Kund Kund { get; set; }

    public int RumId { get; set; }
    public Rum Rum { get; set; }

    public DateTime Incheckning { get; set; }
    public DateTime Utcheckning { get; set; }
}
